module AsmProg where

import X86
import Text
import RunAsm

import Data.Int
import Data.List
import Data.Maybe
import System.Info (os)

data Term = Const Int64
          | Var String
          | Add Term Term
          | Mult Term Term
          | String := Term
          | Seq Term Term
  deriving (Show)

infixl 6 `Add`
infixl 7 `Mult`
infixl 0 `Seq`
infixr 1 :=

sampleTerm = (Const 4 `Add` Const 2) `Mult` (Const 6 `Add` Const 1) -- should evaluate to 42, obvs.
sampleTerm2 = "X" := Const 3 `Seq`
              "Y" := Const 3 `Seq`
              (Var "X" `Add` Var "Y") `Mult` (Var "X" `Add`
                                               ("Y" := Var "Y" `Add` Const 1 `Seq`
                                                Var "Y"))

vars :: Term -> [String]
vars (Const _)    = []
vars (Var x)      = [x]
vars (Add e1 e2)  = vars e1 ++ vars e2
vars (Mult e1 e2) = vars e1 ++ vars e2
vars (x := e)     = x : vars e
vars (Seq e1 e2)  = vars e1 ++ vars e2

comp :: Term -> Prog
comp e =
 [ global "function" $
   [ pushq ~%RBP
   , movq ~%RSP ~%RBP
   , subq ~$(8 * genericLength xs) ~%RSP ] ++
   compTerm xs e ++
   [ popq ~%RAX
   , movq ~%RBP ~%RSP
   , popq ~%RBP
   , retq ] ]
     where xs = nub $ vars e

compBin xs op e1 e2 =
 compTerm xs e1 ++
 compTerm xs e2 ++
 [ popq ~%RAX
 , popq ~%RDX
 , op ~%RDX ~%RAX
 , pushq ~%RAX ]

offset xs x = -8  * (fromIntegral $ fromJust (elemIndex x xs) + 1)

compTerm :: [String] -> Term -> [Instruction]
compTerm _ (Const i) =
 [ pushq ~$i ]
compTerm xs (Add e1 e2) =
 compBin xs addq e1 e2
compTerm xs (Mult e1 e2) =
 compBin xs imulq e1 e2
compTerm xs (Var x) =
  [ pushq ~#(offset xs x, RBP) ]    -- offset(%rbp)
compTerm xs (x := e) =
  compTerm xs e ++
  [ pushq ~#RSP                       -- pushq (%rsp)
  , popq ~#(offset xs x, RBP) ]
      -- can't do this: movq (%rsp) offset(%rbp)
compTerm xs (Seq e1 e2) =
 compTerm xs e1 ++
 [ addq ~$8 ~%RSP ] ++
 compTerm xs e2
