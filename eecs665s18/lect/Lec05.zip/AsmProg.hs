module AsmProg where

import X86
import Text
import RunAsm

import Data.Int
import System.Info (os)

fact1 n =
 [ ("function", True,
    Text [ (Movq, [ Imm (Literal 1), Reg RAX ])
         , (Movq, [ Imm (Literal n), Reg RCX ]) ])
 , ("loop", False,
    Text [ (Cmpq, [ Imm (Literal 0), Reg RCX ])
         , (J Le, [ Imm (Label "exit") ])
         , (Imulq, [Reg RCX, Reg RAX])
         , (Decq, [Reg RCX])
         , (Jmp, [Imm (Label "loop")])])
 , ("exit", False,
    Text [(Retq, [])]) ]

fact2 n =
 [ global "function"
   [ movq ~$1 ~%RAX
   , movq ~$n ~%RCX ]
 , text "loop"
   [ cmpq ~$0 ~%RCX
   , j Le ~$$"exit"
   , imulq ~%RCX ~%RAX
   , decq ~%RCX
   , jmp ~$$"loop" ]
 , text "exit"
   [ retq ] ]

fib n =
 [ global "function"
   [ pushq ~%RBX
   , movq ~$0 ~%RAX
   , movq ~$1 ~%RBX
   , movq ~$n ~%RCX ]
 , text "loop"
   [ cmpq ~$0 ~%RCX
   , j Le ~$$"exit"
   , movq ~%RBX ~%RDX
   , addq ~%RAX ~%RBX
   , movq ~%RDX ~%RAX
   , decq ~%RCX
   , jmp ~$$"loop" ]
 , text "exit"
   [ popq ~%RBX
   , retq ] ]

fibf =
 [ global "function" $
   [ pushq ~%RBX
   , movq ~$0 ~%RAX
   , movq ~$1 ~%RBX ] ++
   (if os == "mingw32" then [] else [movq ~%RDI ~%RCX])
 , text "loop"
   [ cmpq ~$0 ~%RCX
   , j Le ~$$"exit"
   , movq ~%RBX ~%RDX
   , addq ~%RAX ~%RBX
   , movq ~%RDX ~%RAX
   , decq ~%RCX
   , jmp ~$$"loop" ]
 , text "exit"
   [ popq ~%RBX
   , retq ] ]


data Term = Const Int64
          | Add Term Term
          | Mult Term Term
  deriving (Show)

infixl 6 `Add`
infixl 7 `Mult`

sampleTerm = (Const 4 `Add` Const 2) `Mult` (Const 6 `Add` Const 1) -- should evaluate to 42, obvs.

comp e =
 [ global "function" $
   [ pushq ~%RBP
   , movq ~%RSP ~%RBP ] ++
   compTerm e ++
   [ popq ~%RAX
   , movq ~%RBP ~%RSP
   , popq ~%RBP
   , retq ] ]

compBin op e1 e2 =
 compTerm e1 ++
 compTerm e2 ++
 [ popq ~%RAX
 , popq ~%RDX
 , op ~%RDX ~%RAX
 , pushq ~%RAX ]

compTerm (Const i) =
 [ pushq ~$i ]
compTerm (Add e1 e2) =
 compBin addq e1 e2
compTerm (Mult e1 e2) =
 compBin imulq e1 e2
