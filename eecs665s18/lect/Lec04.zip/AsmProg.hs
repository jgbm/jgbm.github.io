module AsmProg where

import X86
import Text

fact1 n =
 [ ("function", True,
    Text [ (Movq, [ Imm (Literal 1), Reg RAX ])
         , (Movq, [ Imm (Literal n), Reg RCX ]) ])
 , ("loop", False,
    Text [ (Cmpq, [ Imm (Literal 0), Reg RCX ])
         , (J Le, [ Imm (Label "exit") ])
         , (Imulq, [Reg RCX, Reg RAX])
         , (Decq, [Reg RCX])
         , (Jmp, [Imm (Label "loop")])])
 , ("exit", False,
    Text [(Retq, [])]) ]

fact2 n =
 [ global "function"
   [ movq ~$1 ~%RAX
   , movq ~$n ~%RCX ]
 , text "loop"
   [ cmpq ~$0 ~%RCX
   , j Le ~$$"exit"
   , imulq ~%RCX ~%RAX
   , decq ~%RCX
   , jmp ~$$"loop" ]
 , text "exit"
   [ retq ] ]
