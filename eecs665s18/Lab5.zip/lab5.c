#include <stdio.h>
#include <stdint.h>

int64_t f(int64_t a) {
  int64_t i = 0;
  for (; a > 1; i++)
    if ((a & 1) == 0)
      a = a >> 1;
    else
      a = 3 * a + 1;
  return i;
}

int main() {
  printf("%lld %lld %lld\n", f(5), f(9), f(64));
  return 0;
}
