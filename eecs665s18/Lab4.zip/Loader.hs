module Loader where

import Data.Array.IArray
import Data.Char
import Data.Int
import Data.List
import Data.Maybe

import Machine
import X86

--------------------------------------------------------------------------------
-- Executable images                                                          --
--------------------------------------------------------------------------------

{-

An executable image is a half-way point between the source assembly language
program and the machine image.  You can think of it as a dramatic simplification
of the ELF or PE formats used in practice.

Our executable images contain:

  - The list of `SByte`s making up the executable code, called `textSegment`,
    along with the starting address for the text segment `textAddr`;

  - The list of `SByte`s making up the data, called `dataSegment`, along with
    the starting byte for the data segment `dataAddr`;

  - The starting address for execution (i.e., the initial RIP), called `start`.
    Note that this means that execution need not start at the lowest address in
    the code segment.
-}

data Executable = E { start, textAddr, dataAddr :: Int64
                    , textSegment, dataSegment :: [SByte] }

--------------------------------------------------------------------------------
-- Assembler                                                                  --
--------------------------------------------------------------------------------

{-

Your first task is to write an assembler (and linker); this is responsible for
taking a `Prog` value and producing an `Executable` value.  Conceptually, this
has three steps.

 - You need to transform the blocks of assembly code in the source program into
   a continuous stream of `SByte`s.  The interesting step here is that you need
   to turn textual labels in the source program into concrete integers in the
   executable image.

 - You need to transform the data blocks in the source program into a stream of
   `SByte`s.  Note that, following the slides, we want all labels in a generated
   program to be 4-byte aligned.  For the instruction stream, this will be easy,
   as we are assuming that all instructions are represented by 4-`SByte`
   sequences.  For data values, you will have to ensure that each label is on a
   4-byte boundary, inserting padding (0 bytes will do) if needed.

 - Finally, you will need to compute the start address.  Assume that programs
   will always start execution with the "main" label.

A couple of tips.

 - You may find Haskell's list-folding functions---`foldl` and `foldr`---
   particularly useful in implementing your assembler.

 - You do not need to handle errors gracefully---if the program refers to a
   label that does not exist, for example, your assembler can just crash.

 - While it is not mandatory, the sample solutions will always place the code
   segment below the data segment in memory.  If you do the same, you may find
   it easier to compare your results against the provided machine images.

-}


assemble :: Prog -> Executable
assemble = error "unimplemented"

--------------------------------------------------------------------------------
-- Loader                                                              --
--------------------------------------------------------------------------------

{-

Second, you will write a loader, which transforms and `Executable` program into
a machine image.  That is, you will have to produce a machine image with the
`textSegment` loaded into memory starting from `textAddr`, the `dataSegment`
loaded into memory starting from `dataAddr`, and with the registers set to begin
execution.

A few tips:

 - The Machine module defines a value `zeroMachine`, which is a machine image
   with everything set to 0.  You may find it helpful to build your machine
   image starting from `zeroMachine`.

 - The Haskell array update operator (//) can be used to do a number of updates
   at once.  So, for example, to update bytes i,..,i+3 to b1,..b4, you could do

       mem // [(i, b1), (i + 1, b2), (i + 2, b3), (i + 3, b4)]

 - Be sure to initialize both the instruction pointer and the stack pointer.

-}

load :: Executable -> Machine
load = error "unimplemented"
